﻿using System.Windows.Forms;
using System.Drawing;

namespace PEOPLE
{
    public class Slot
    {
        public Carta CartaOccupante { get; private set; }
        public bool Occupato => CartaOccupante != null;
        private PictureBox pictureBox;

        public Slot(PictureBox pictureBox)
        {
            this.pictureBox = pictureBox;
            this.pictureBox.BorderStyle = BorderStyle.FixedSingle;
            this.pictureBox.SizeMode = PictureBoxSizeMode.StretchImage;
            this.pictureBox.BackColor = Color.Black; // Sfondo nero per slot vuoti
        }

        public void AssegnaCarta(Carta carta)
        {
            CartaOccupante = carta;
            pictureBox.Image = Image.FromFile(carta.ImmaginePath); // Mostra l'immagine della carta
        }

        public void RimuoviCarta()
        {
            CartaOccupante = null;
            pictureBox.Image = null; // Rimuove l'immagine quando la carta viene tolta
        }
    }
}
