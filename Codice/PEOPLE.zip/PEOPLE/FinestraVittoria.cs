﻿using System;
using System.Windows.Forms;

namespace PEOPLE
{
    public class FinestraVittoria : Form
    {
        public FinestraVittoria(string vincitore)
        {
            this.Text = "Partita Terminata";
            this.Size = new Size(400, 200);
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.StartPosition = FormStartPosition.CenterScreen;

            Label lblMessaggio = new Label
            {
                Text = $"{vincitore} ha vinto la partita!",
                AutoSize = true,
                Font = new System.Drawing.Font("Arial", 14, System.Drawing.FontStyle.Bold),
                Location = new System.Drawing.Point(100, 50)
            };
            this.Controls.Add(lblMessaggio);

            Button btnOK = new Button
            {
                Text = "OK",
                Size = new Size(100, 30),
                Location = new System.Drawing.Point(150, 100)
            };
            btnOK.Click += (sender, e) => TornaAllaSchermataTitolo();
            this.Controls.Add(btnOK);
        }

        private void TornaAllaSchermataTitolo()
        {
            SchermataTitolo schermataTitolo = new SchermataTitolo();
            schermataTitolo.Show();
            this.Close(); // Chiude la finestra di vittoria
        }

        public void MostraFinestraVittoria(string vincitore,bool ShowForms)
        {
            FinestraVittoria finestra = new FinestraVittoria(vincitore);
            if (ShowForms)
            {
                finestra.Show();
                this.Close();
            }// Chiude la partita
        }

    }
}
