﻿using System;
using System.Drawing.Interop;
using System.Windows.Forms;
using Microsoft.VisualBasic.Logging;

namespace PEOPLE
{
    public class Turno
    {
        private int numeroTurno, LifePointsUser, LifePointsCPU;
        private int giocatoreDiTurno;// 1 = User, 2 = CPU
        private FaseTurno FaseAttuale;
        private Log logForm;
        private Mazzo mazzoUser;
        private Mazzo mazzoCPU;
        private Mano manoUser;
        private Mano manoCPU;
        private ManoForm ManoForm;
        private Mazzo cimiteroUser, cimiteroCPU;
        private Mazzo carteRimosseUser, carteRimosseCPU;
        private Slot[] slotPersonaggiUser, slotPersonaggiCPU, slotMagieUser, slotMagieCPU;
        private Slot[] magiaTerrenoUser, magiaTerrenoCPU;
        private Battaglia my_battle;


        //LifePointsTextUser, LifePointsTextCPU,slotPersonaggiUser, slotPersonaggiCPU, slotMagieUser, slotMagieCPU, magiaTerrenoUser, magiaTerrenoCPU)


        public enum Fasi
        {
            StartTurn = 0,
            DrawPhase = 1,
            MainPhase1 = 2,
            BattlePhase = 3,
            MainPhase2 = 4,
            EndPhase = 5
        }

        public Turno(Log logForm, Mazzo mazzoUser, Mazzo mazzoCPU, Mano manoUser, Mano manoCPU, ManoForm manoForm,
            Mazzo cimiteroUser, Mazzo cimiteroCPU, Mazzo carteRimosseUser, Mazzo carteRimosseCPU, int giocatoreDiTurno, int numeroTurno, int LifePointsUser,
            int LifePointsCPU, Slot[] slotPersonaggiUser, Slot[] slotPersonaggiCPU, Slot[] slotMagieUser, Slot[] slotMagieCPU, Slot[] magiaTerrenoUser,
            Slot[] magiaTerrenoCPU, Battaglia my_battle)
        {
            
           
            FaseAttuale = new FaseTurno(0, logForm, mazzoUser, mazzoCPU, manoUser, manoCPU,manoForm, 
                cimiteroUser, cimiteroCPU,carteRimosseUser,carteRimosseCPU,giocatoreDiTurno, numeroTurno, LifePointsUser, LifePointsCPU,
                slotPersonaggiUser, slotPersonaggiCPU, slotMagieUser, slotMagieCPU, magiaTerrenoUser, magiaTerrenoCPU,my_battle);


           
            // Inizializza la Draw Phase
            FaseAttuale.CambiaFase((int)Fasi.StartTurn);
        }

        

       
    }
}


