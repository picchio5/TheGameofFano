﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace PEOPLE
{
    public partial class ManoForm : Form
    {
        private Mano mano;

        public ManoForm(Mano mano)
        {

            this.mano = mano;
            CaricaCarteInMano();
        }

        private void CaricaCarteInMano()
        {
            int x = 20; // Posizione iniziale della prima carta

            foreach (Carta carta in mano.Carte)
            {
                PictureBox pbCarta = new PictureBox
                {
                    Image = Image.FromFile(carta.ImmaginePath),
                    SizeMode = PictureBoxSizeMode.StretchImage,
                    Size = new Size(100, 150),
                    Location = new Point(x, 50)
                };

                this.Controls.Add(pbCarta);
                x += 110; // Sposta la prossima carta più a destra
            }
        }

        private void InitializeComponent()
        {

        }

        public void AggiornaMano()
        {
            this.Controls.Clear(); // Rimuove le vecchie carte

            int x = 10; // Posizione iniziale per le carte
            foreach (var carta in mano.Carte)
            {
                PictureBox pb = new PictureBox
                {
                    Image = Image.FromFile(carta.ImmaginePath),
                    SizeMode = PictureBoxSizeMode.StretchImage,
                    Size = new Size(100, 150),
                    Location = new Point(x, 10)
                };

                this.Controls.Add(pb);
                x += 110; // Sposta la posizione per la prossima carta
            }
        }
    }
}
