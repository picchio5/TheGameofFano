﻿using System;
using System.Drawing;
using System.Windows.Forms;
using System.Collections.Generic;
using System.Linq;
using System.Drawing.Interop;

namespace PEOPLE
{
    public partial class Battaglia : Form
    {
        private Mazzo mazzoUser, mazzoCPU, cimiteroUser, carteRimosseUser,cimiteroCPU,carteRimosseCPU;
        private PictureBox ImageMazzoCPU, ImageMazzoUser, cimiteroUserBox,cimiteroCPUBox,carteRimosseUserBox,carteRimosseCPUBox,magiaTerrenoUserBox,magiaTerrenoCPUBox;
        private ProgressBar LifePointsCPU, LifePointsUser;
        private TextBox LifePointsTextUser, LifePointsTextCPU;
        private ToolTip toolTipMazzoUser, toolTipMazzoCPU,toolTipcimiteroUser, toolTipcimiteroCPU, toolTiprimosseUser, toolTiprimosseCPU;
        private Slot[] slotPersonaggiUser,slotPersonaggiCPU,slotMagieUser,slotMagieCPU;
        private Slot[] magiaTerrenoUser, magiaTerrenoCPU;
        private int deckSize, CarteInMano, MaxLifePoints;
        private float isMyDeckRandom, isCPUDeckRandom;
        private Mano manoUser, manoCPU;
        private Random random = new Random();
        private Log logForm;
        private Turno turnoAttuale;
        private FaseTurno FaseAttuale;
        private int currentLifePointsUser;
        private int currentLifePointsCPU;
        private CimiteroForm cimiteroFormUser;
        private CimiteroForm cimiteroFormCPU;
        public bool fineMazzoPerdi;
        private FinestraVittoria FinestraVittoria;
        public bool ShowForms;
        public int Vincitore;

        public Battaglia(int deckSize, float isMyDeckRandom, float isCPUDeckRandom, int MaxLifePoints, int CarteInMano, Log logForm, bool fineMazzoPerdi,bool ShowForms)
        {
            InitializeComponent();
            this.deckSize = deckSize;
            this.isMyDeckRandom = isMyDeckRandom;
            this.isCPUDeckRandom = isCPUDeckRandom;
            this.MaxLifePoints = MaxLifePoints;
            this.CarteInMano = CarteInMano;
            this.logForm = logForm;
            currentLifePointsUser = MaxLifePoints;
            currentLifePointsCPU = MaxLifePoints;
            this.fineMazzoPerdi= fineMazzoPerdi;
            this.ShowForms = ShowForms;
            // this.logForm = new Log(deckSize, isMyDeckRandom, isCPUDeckRandom, MaxLifePoints, CarteInMano); // INIZIALIZZAZIONE PRIMA DI USARLO
            //logForm.Show(); // Mostra la finestra log


            // Creazione mazzi
            mazzoUser = new Mazzo();
            mazzoCPU = new Mazzo();
            cimiteroUser = new Mazzo();
            carteRimosseUser = new Mazzo();
            cimiteroCPU = new Mazzo();
            carteRimosseCPU = new Mazzo();

            // Caricamento carte
            ArchivioCarte.CaricaCarte();
            mazzoUser = CreaMazzoCasuale(deckSize);
            mazzoCPU = CreaMazzoCasuale(deckSize);

            // Creazione della mano
            manoUser = new Mano();
            manoCPU = new Mano();
            for (int i = 0; i < CarteInMano; i++)
            {
                if (mazzoUser.Carte.Count > 0) manoUser.AggiungiCarta(mazzoUser.PescaCarta(mazzoUser,1,this,logForm));
                if (mazzoCPU.Carte.Count > 0) manoCPU.AggiungiCarta(mazzoCPU.PescaCarta(mazzoCPU, 2, this, logForm));
            }

            // Mostra il form Mano
            ManoForm manoForm = new ManoForm(manoUser);
            if (ShowForms)
            {
                manoForm.Show();
            }

            // Creazione interfaccia
            CreaInterfacciaMazzi();
            InizializzaComponentiBattaglia();
            //logForm.InizializzaLog(deckSize,isMyDeckRandom, isCPUDeckRandom, MaxLifePoints,  CarteInMano);

            // Scelta primo giocatore e inizio turno
            int giocatoreDiTurno = random.Next(1, 3);
            FaseAttuale = new FaseTurno(0, logForm, mazzoUser, mazzoCPU, manoUser, manoCPU, manoForm,
                cimiteroUser, cimiteroCPU, carteRimosseUser, carteRimosseCPU, giocatoreDiTurno, 1, MaxLifePoints, MaxLifePoints,
                slotPersonaggiUser, slotPersonaggiCPU, slotMagieUser, slotMagieCPU, magiaTerrenoUser, magiaTerrenoCPU,this);
            FaseAttuale.CambiaFase(0);

            LiberaRisorseBattaglia();




            return;
        }

        private Mazzo CreaMazzoCasuale(int numeroCarte)
        {
            Mazzo mazzo = new Mazzo();
            if (ArchivioCarte.TutteLeCarte.Count < numeroCarte)
            {
                MessageBox.Show("Non ci sono abbastanza carte nel database!");
                return mazzo;
            }
            mazzo.Carte.AddRange(ArchivioCarte.TutteLeCarte.OrderBy(x => random.Next()).Take(numeroCarte));
            return mazzo;
        }

        private void CreaInterfacciaMazzi()
        {
            

            // Mazzo User (in basso a destra)
            ImageMazzoUser = new PictureBox
            {
                Image = Image.FromFile("C:\\Users\\stefa\\Documents\\CARTE PEOPLE\\Mazzobrutto.png"),
                SizeMode = PictureBoxSizeMode.StretchImage,
                Size = new Size(100, 150),
                Location = new Point(this.ClientSize.Width - 225, this.ClientSize.Height+300),
                BorderStyle = BorderStyle.FixedSingle
            };

            // Mazzo CPU (in alto a sinistra)
            ImageMazzoCPU = new PictureBox
            {
                Image = Image.FromFile("C:\\Users\\stefa\\Documents\\CARTE PEOPLE\\Mazzobrutto.png"),
                SizeMode = PictureBoxSizeMode.StretchImage,
                Size = new Size(100, 150),
                Location = new Point(ImageMazzoUser.Location.X - 250 * 6, 200),
                BorderStyle = BorderStyle.FixedSingle
            };

            

            
           

            // Cimitero sopra il mazzo User
            cimiteroUserBox = new PictureBox
            {
                Size = new Size(100, 150),
                Location = new Point(ImageMazzoUser.Location.X, ImageMazzoUser.Location.Y - 160),
                BorderStyle = BorderStyle.FixedSingle,
                BackColor = Color.Black
            };

            cimiteroCPUBox = new PictureBox
            {
                Size = new Size(100, 150),
                Location = new Point(ImageMazzoCPU.Location.X, ImageMazzoCPU.Location.Y + 160),
                BorderStyle = BorderStyle.FixedSingle,
                BackColor = Color.Black
            };

          
            // Carte Rimosse accanto al Cimitero
            carteRimosseUserBox = new PictureBox
            {
                Size = new Size(100, 150),
                Location = new Point(cimiteroUserBox.Location.X + 120, cimiteroUserBox.Location.Y),
                BorderStyle = BorderStyle.FixedSingle,
                BackColor = Color.Black
            };

            carteRimosseCPUBox = new PictureBox
            {
                Size = new Size(100, 150),
                Location = new Point(cimiteroCPUBox.Location.X - 120, cimiteroCPUBox.Location.Y),
                BorderStyle = BorderStyle.FixedSingle,
                BackColor = Color.Black
            };

           
            // Magia Terreno in alto a sinistra
            magiaTerrenoUserBox = new PictureBox
            {
                Size = new Size(100, 150),
                Location = new Point(ImageMazzoUser.Location.X-250*6, ImageMazzoUser.Location.Y),
                BorderStyle = BorderStyle.FixedSingle,
                BackColor = Color.Black
            };


            magiaTerrenoCPUBox = new PictureBox
            {
                Size = new Size(100, 150),
                Location = new Point(ImageMazzoCPU.Location.X + 250 * 6, ImageMazzoCPU.Location.Y),
                BorderStyle = BorderStyle.FixedSingle,
                BackColor = Color.Black
            };

            toolTipMazzoUser = new ToolTip();
            toolTipMazzoCPU = new ToolTip();
            toolTipcimiteroUser = new ToolTip();
            toolTipcimiteroCPU = new ToolTip();
            toolTiprimosseUser = new ToolTip();
            toolTiprimosseCPU = new ToolTip();
            ImageMazzoUser.MouseHover += (sender, e) => toolTipMazzoUser.SetToolTip(ImageMazzoUser, $"Carte rimaste: {mazzoUser.Carte.Count}");
            ImageMazzoCPU.MouseHover += (sender, e) => toolTipMazzoCPU.SetToolTip(ImageMazzoCPU, $"Carte rimaste: {mazzoCPU.Carte.Count}");
            cimiteroUserBox.MouseHover += (sender, e) => toolTipcimiteroUser.SetToolTip(cimiteroUserBox, $"Carte presenti: {cimiteroUser.Carte.Count}");
            cimiteroCPUBox.MouseHover += (sender, e) => toolTipcimiteroCPU.SetToolTip(cimiteroCPUBox, $"Carte presenti: {cimiteroCPU.Carte.Count}");
            carteRimosseUserBox.MouseHover += (sender, e) => toolTiprimosseUser.SetToolTip(carteRimosseUserBox, $"Carte presenti: {carteRimosseUser.Carte.Count}");
            carteRimosseCPUBox.MouseHover += (sender, e) => toolTiprimosseCPU.SetToolTip(carteRimosseCPUBox, $"Carte presenti: {carteRimosseCPU.Carte.Count}");



            // Slot Personaggi e Magie
            slotPersonaggiUser = new Slot[5];
            slotMagieUser = new Slot[5];
            slotPersonaggiCPU = new Slot[5];
            slotMagieCPU= new Slot[5];
            magiaTerrenoUser = new Slot[1];
            magiaTerrenoCPU = new Slot[1];

            for (int i = 0; i < 5; i++)
            {
                PictureBox slotPers = new PictureBox
                {
                    Size = new Size(100, 150),
                    Location = new Point(ImageMazzoUser.Location.X-((i+1)*250), ImageMazzoUser.Location.Y),
                    BorderStyle = BorderStyle.FixedSingle,
                    BackColor = Color.Black
                };
                this.Controls.Add(slotPers);
                slotPersonaggiUser[i] = new Slot(slotPers);

                PictureBox slotMag = new PictureBox
                {
                    Size = new Size(100, 150),
                    Location = new Point(ImageMazzoUser.Location.X - ((i + 1) * 250), ImageMazzoUser.Location.Y+210),
                    BorderStyle = BorderStyle.FixedSingle,
                    BackColor = Color.Black
                };
                this.Controls.Add(slotMag);
                slotMagieUser[i] = new Slot(slotMag);
            }

            for (int i = 0; i < 5; i++)
            {
                PictureBox slotPers = new PictureBox
                {
                    Size = new Size(100, 150),
                    Location = new Point(ImageMazzoCPU.Location.X + ((i + 1) * 250), ImageMazzoCPU.Location.Y),
                    BorderStyle = BorderStyle.FixedSingle,
                    BackColor = Color.Black
                };
                this.Controls.Add(slotPers);
                slotPersonaggiCPU[i] = new Slot(slotPers);

                PictureBox slotMag = new PictureBox
                {
                    Size = new Size(100, 150),
                    Location = new Point(ImageMazzoCPU.Location.X + ((i + 1) * 250), ImageMazzoCPU.Location.Y-210),
                    BorderStyle = BorderStyle.FixedSingle,
                    BackColor = Color.Black
                };
                this.Controls.Add(slotMag);
                slotMagieCPU[i] = new Slot(slotMag);
            }

            
           
           
        }

        // Metodo per aggiornare la barra e la textbox dei Life Points
        public void AggiornaLifePointsUI(int giocatoreDiTurno,int currentLifePoints)
        {
            if (giocatoreDiTurno == 1)
            {
                AggiornaLifePointsUser(currentLifePoints);
            }
            else
            {
                AggiornaLifePointsCPU(currentLifePoints);
            }
        }

        public bool ControllaFinePartita(int LPUser, int LPCPU)
        {
            if (LPUser <= 0)
            {
                logForm.AggiungiMessaggio("User ha perso! CPU vince!");
                Vincitore = 2;
                FinestraVittoria = new FinestraVittoria("CPU");
                FinestraVittoria.MostraFinestraVittoria("CPU",ShowForms);
                return true;
            }
            else if (LPCPU <= 0)
            {
                logForm.AggiungiMessaggio("CPU ha perso! User vince!");
                Vincitore =1;
                FinestraVittoria = new FinestraVittoria("User");
                FinestraVittoria.MostraFinestraVittoria("User",ShowForms);
                return true;
            }
            else
            {
                return false;
            }
        }


        public void AggiornaLifePointsUser(int nuoviLifePoints)
        {
            currentLifePointsUser = (nuoviLifePoints > 0 ? nuoviLifePoints : 0);
            LifePointsUser.Value = (nuoviLifePoints > 0 ? nuoviLifePoints : 0);
            LifePointsTextUser.Text = $"Life Points: {(nuoviLifePoints > 0 ? nuoviLifePoints : 0)}";
            FaseAttuale.LifePointsUser = (nuoviLifePoints > 0 ? nuoviLifePoints : 0);
            
            this.Controls.Add(LifePointsCPU);
            this.Controls.Add(LifePointsTextCPU);
        }

        public void AggiornaLifePointsCPU(int nuoviLifePoints)
        {
            currentLifePointsCPU = (nuoviLifePoints > 0 ? nuoviLifePoints : 0);
            LifePointsCPU.Value = (nuoviLifePoints > 0 ? nuoviLifePoints : 0);
            LifePointsTextCPU.Text = $"Life Points: {(nuoviLifePoints > 0 ? nuoviLifePoints : 0)}";
            FaseAttuale.LifePointsCPU = (nuoviLifePoints > 0 ? nuoviLifePoints : 0);

            this.Controls.Add(LifePointsCPU);
            this.Controls.Add(LifePointsTextCPU);
        }

        private void InizializzaComponentiBattaglia()
        {
            if (ShowForms)
            {
                this.WindowState = FormWindowState.Maximized;
            }

            // Barra Life Points
            LifePointsUser = new ProgressBar
            {
                Size = new Size(300, 20),
                Location = new Point(ImageMazzoUser.Location.X - 100, ImageMazzoUser.Location.Y + 160),
                Maximum = MaxLifePoints,
                Value = MaxLifePoints
            };

            LifePointsCPU = new ProgressBar
            {
                Size = new Size(300, 20),
                Location = new Point(ImageMazzoCPU.Location.X - 100, ImageMazzoCPU.Location.Y - 30),
                Maximum = MaxLifePoints,
                Value = MaxLifePoints
            };

            // TextBox Life Points
            LifePointsTextUser = new TextBox
            {
                Size = new Size(300, 20),
                Location = new Point(LifePointsUser.Location.X, LifePointsUser.Location.Y + 30),
                ReadOnly = true,
                Text = $"Life Points: {MaxLifePoints}"
            };

            LifePointsTextCPU = new TextBox
            {
                Size = new Size(300, 20),
                Location = new Point(LifePointsCPU.Location.X, LifePointsCPU.Location.Y - 30),
                ReadOnly = true,
                Text = $"Life Points: {MaxLifePoints}"
            };

            if (ShowForms)
            {
                this.Controls.Add(LifePointsUser);
                this.Controls.Add(LifePointsTextUser);
                this.Controls.Add(LifePointsCPU);
                this.Controls.Add(LifePointsTextCPU);
                this.Controls.Add(ImageMazzoUser);
                this.Controls.Add(ImageMazzoCPU);
                this.Controls.Add(magiaTerrenoUserBox);
                this.Controls.Add(magiaTerrenoCPUBox);
                this.Controls.Add(cimiteroUserBox);
                this.Controls.Add(cimiteroCPUBox);
                this.Controls.Add(carteRimosseUserBox);
                this.Controls.Add(carteRimosseCPUBox);
                this.Controls.Add(ImageMazzoUser);
                this.Controls.Add(ImageMazzoCPU);
            }

         


        cimiteroUserBox.Click += (sender, e) =>
            {
                if (cimiteroUser.Carte.Count > 0)
                {
                    CimiteroForm cimiteroForm = new CimiteroForm(cimiteroUser);
                    cimiteroForm.Show();
                }
            };

            cimiteroCPUBox.Click += (sender, e) =>
            {
                if (cimiteroCPU.Carte.Count > 0)
                {
                    CimiteroForm cimiteroForm = new CimiteroForm(cimiteroCPU);
                    cimiteroForm.Show();
                }
            };



        }

        public void AggiornaCimiteroUI()
        {
            if (cimiteroUser.Carte.Count > 0)
            {
                Carta ultimaCarta = cimiteroUser.Carte.Last();
                cimiteroUserBox.Image = Image.FromFile(ultimaCarta.ImmaginePath);
                cimiteroUserBox.Size = new Size(100, 150);
            }
            else
            {
                cimiteroUserBox.Image = null; // Nessuna carta nel cimitero → niente immagine
            }

            if (cimiteroCPU.Carte.Count > 0)
            {
                Carta ultimaCarta = cimiteroCPU.Carte.Last();
                cimiteroCPUBox.Image = Image.FromFile(ultimaCarta.ImmaginePath);
                cimiteroCPUBox.Size = new Size(100, 150);
            }
            else
            {
                cimiteroUserBox.Image = null; // Nessuna carta nel cimitero → niente immagine
            }
        }


        private void LiberaRisorseBattaglia()
        {
            // Dispose di tutti i Form
            logForm?.Dispose();
            cimiteroFormUser?.Dispose();
            cimiteroFormCPU?.Dispose();
            FinestraVittoria?.Dispose();

            // Dispose di tutti i ToolTip
            toolTipMazzoUser?.Dispose();
            toolTipMazzoCPU?.Dispose();
            toolTipcimiteroUser?.Dispose();
            toolTipcimiteroCPU?.Dispose();
            toolTiprimosseUser?.Dispose();
            toolTiprimosseCPU?.Dispose();

            // Dispose di tutti i PictureBox
            ImageMazzoCPU?.Dispose();
            ImageMazzoUser?.Dispose();
            cimiteroUserBox?.Dispose();
            cimiteroCPUBox?.Dispose();
            carteRimosseUserBox?.Dispose();
            carteRimosseCPUBox?.Dispose();
            magiaTerrenoUserBox?.Dispose();
            magiaTerrenoCPUBox?.Dispose();

            // Dispose di ProgressBar e TextBox
            LifePointsCPU?.Dispose();
            LifePointsUser?.Dispose();
            LifePointsTextUser?.Dispose();
            LifePointsTextCPU?.Dispose();

            // Pulizia degli array di Slot
            slotPersonaggiUser = null;
            slotPersonaggiCPU = null;
            slotMagieUser = null;
            slotMagieCPU = null;
            magiaTerrenoUser = null;
            magiaTerrenoCPU = null;

            // Pulizia di tutte le variabili di logica
            mazzoUser = null;
            mazzoCPU = null;
            cimiteroUser = null;
            carteRimosseUser = null;
            cimiteroCPU = null;
            carteRimosseCPU = null;
            manoUser = null;
            manoCPU = null;
            turnoAttuale = null;
            FaseAttuale = null;
            random = null;

            // Reset dei counter
            currentLifePointsUser = 0;
            currentLifePointsCPU = 0;
           

            // Forza il garbage collector a lavorare subito
            GC.Collect();
            GC.WaitForPendingFinalizers();
        }


    }
}
