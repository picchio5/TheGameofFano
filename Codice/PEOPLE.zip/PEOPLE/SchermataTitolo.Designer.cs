﻿namespace PEOPLE
{
    partial class SchermataTitolo
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Avvia_Battaglia_Con_CPU = new Button();
            Avvia_X_Battaglie_CPU_vs_CPU = new Button();
            Numero_Battaglie_CPU_vs_CPU = new TextBox();
            SuspendLayout();
            // 
            // Avvia_Battaglia_Con_CPU
            // 
            Avvia_Battaglia_Con_CPU.Location = new Point(290, 175);
            Avvia_Battaglia_Con_CPU.Name = "Avvia_Battaglia_Con_CPU";
            Avvia_Battaglia_Con_CPU.Size = new Size(218, 23);
            Avvia_Battaglia_Con_CPU.TabIndex = 0;
            Avvia_Battaglia_Con_CPU.Text = "Avvia Battaglia con CPU";
            Avvia_Battaglia_Con_CPU.UseVisualStyleBackColor = true;
            Avvia_Battaglia_Con_CPU.Click += Avvia_Battaglia_Con_CPU_Click;
            // 
            // Avvia_X_Battaglie_CPU_vs_CPU
            // 
            Avvia_X_Battaglie_CPU_vs_CPU.Location = new Point(287, 255);
            Avvia_X_Battaglie_CPU_vs_CPU.Name = "Avvia_X_Battaglie_CPU_vs_CPU";
            Avvia_X_Battaglie_CPU_vs_CPU.Size = new Size(221, 23);
            Avvia_X_Battaglie_CPU_vs_CPU.TabIndex = 1;
            Avvia_X_Battaglie_CPU_vs_CPU.Text = "Avvia_X_Battaglie_CPU_vs_CPU";
            Avvia_X_Battaglie_CPU_vs_CPU.UseVisualStyleBackColor = true;
            Avvia_X_Battaglie_CPU_vs_CPU.Click += Avvia_X_Battaglie_CPU_vs_CPU_Click;
            // 
            // Numero_Battaglie_CPU_vs_CPU
            // 
            Numero_Battaglie_CPU_vs_CPU.Location = new Point(551, 266);
            Numero_Battaglie_CPU_vs_CPU.Name = "Numero_Battaglie_CPU_vs_CPU";
            Numero_Battaglie_CPU_vs_CPU.Size = new Size(100, 23);
            Numero_Battaglie_CPU_vs_CPU.TabIndex = 2;
            // 
            // SchermataTitolo
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(Numero_Battaglie_CPU_vs_CPU);
            Controls.Add(Avvia_X_Battaglie_CPU_vs_CPU);
            Controls.Add(Avvia_Battaglia_Con_CPU);
            Name = "SchermataTitolo";
            Text = "Schermata Titolo";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button Avvia_Battaglia_Con_CPU;
        private Button Avvia_X_Battaglie_CPU_vs_CPU;
        private TextBox Numero_Battaglie_CPU_vs_CPU;
    }
}
