﻿using System;
using System.Collections.Generic;

namespace PEOPLE
{
    public class Mazzo
    {
        public List<Carta> Carte { get; private set; }  // Lista di carte nel mazzo
        private FinestraVittoria FinestraVittoria;
        public Mazzo()
        {
            Carte = new List<Carta>();  // Inizializza il mazzo vuoto
        }

        // Aggiunge una carta al mazzo
        public void AggiungiCarta(Carta carta)
        {
            Carte.Add(carta);
        }

        // Rimuove una carta dal mazzo
        public bool RimuoviCarta(Carta carta)
        {
            return Carte.Remove(carta);
        }

        // Mescola le carte nel mazzo
        public void Mescola()
        {
            Random rnd = new Random();
            int n = Carte.Count;
            for (int i = n - 1; i > 0; i--)
            {
                int j = rnd.Next(0, i + 1);
                (Carte[i], Carte[j]) = (Carte[j], Carte[i]);  // Scambio
            }
        }

       
        public Carta PescaCarta(Mazzo mazzo, int giocatore, Battaglia my_battle, Log logForm)
        {
            if (mazzo.Carte.Count == 0)
            {
                if (my_battle.fineMazzoPerdi)
                {
                    logForm.AggiungiMessaggio($"{(giocatore == 1 ? "User" : "CPU")} ha tentato di pescare da un mazzo vuoto e ha perso!");
                    FinestraVittoria= new FinestraVittoria(giocatore == 1 ? "CPU" : "User"); // Perde chi ha provato a pescare
                    return null;
                }
                else
                {
                    logForm.AggiungiMessaggio($"{(giocatore == 1 ? "User" : "CPU")} ha un mazzo vuoto e non può pescare.");
                    return null;
                }
            }

            Carta pescata = Carte[0];
            Carte.RemoveAt(0);
            logForm.AggiungiMessaggio($"{(giocatore == 1 ? "User" : "CPU")} ha pescato {pescata.Nome}.");
            return pescata;
        }

        // Sposta una carta da questo mazzo al Cimitero o alla Zona Carte Rimosse
        public void SpostaCartaIn(Mazzo destinazione, Carta carta)
        {
            if (Carte.Remove(carta))
            {
                destinazione.AggiungiCarta(carta);
            }
        }

        // Restituisce l'ultima carta del mazzo (utile per vedere la carta in cima al Cimitero)
        public Carta UltimaCarta()
        {
            if (Carte.Count > 0)
                return Carte[^1]; // Prende l'ultima carta
            return null;
        }
    }
}
