﻿using System;
using System.Drawing;
using System.Windows.Forms;
namespace PEOPLE
{
    public partial class Log : Form
    {
        private TextBox logTextBox;
        public Log(int deckSize, float isMyDeckRandom, float isCPUDeckRandom, int MaxLifePoints, int CarteInMano)
        {
            InizializzaTextBox();
            InizializzaLog(deckSize, isMyDeckRandom, isCPUDeckRandom,MaxLifePoints, CarteInMano);
            
        }

        private void InizializzaTextBox()
        {
            logTextBox = new TextBox
            {
                Multiline = true,
                ReadOnly = true,
                Dock = DockStyle.Fill,
                Font = new System.Drawing.Font("Arial", 12),
                ScrollBars = ScrollBars.Vertical
            };

            this.Controls.Add(logTextBox);
        }

        private void InizializzaLog(int deckSize, float isMyDeckRandom, float isCPUDeckRandom, int MaxLifePoints, int CarteInMano)
        {
            // Creazione della TextBox per mostrare il log
           

            // Generazione del messaggio di log
            string logMessage = $"BATTAGLIA INIZIATA - {DateTime.Now}\r\n" +
                                $"La frazione di carte random nel mazzo User è {isMyDeckRandom}\r\n" +
                                $"La frazione di carte random nel mazzo CPU è {isCPUDeckRandom}\r\n" +
                                $"I mazzi hanno {deckSize} carte.\r\n" +
                                $"I giocatori hanno {MaxLifePoints} Life Points.\r\n" +
                                $"I giocatori iniziano con {CarteInMano} Carte in Mano.\r\n" +
                                $"---------------------------------------------- \r\n";



            logTextBox.AppendText(logMessage);
        }

        public void AggiungiMessaggio(string messaggio)
        {
            logTextBox.AppendText(messaggio + Environment.NewLine);
        }
    }
}
