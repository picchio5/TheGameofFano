﻿using System.Diagnostics.Eventing.Reader;
using Microsoft.VisualBasic.Logging;

namespace PEOPLE
{
    public class FaseTurno
    {
        public int Fase { get; private set; }
        private Log logForm;
        private Mazzo mazzoUser;
        private Mazzo mazzoCPU;
        private Mano manoUser;
        private Mano manoCPU;
        private int giocatoreDiTurno;
        private ManoForm manoForm;
        public int numeroTurno, LifePointsUser, LifePointsCPU;
        private Mazzo cimiteroUser;
        private Mazzo cimiteroCPU;
        private Mazzo carteRimosseUser;
        private Mazzo carteRimosseCPU;
        private Slot[] slotPersonaggiUser, slotPersonaggiCPU, slotMagieUser, slotMagieCPU;
        private Slot[] magiaTerrenoUser, magiaTerrenoCPU;
        private Scelta Choice_MainPhase1,Choice_BattlePhase;
        private int evocazioni_normali_rimaste;
        private Battaglia my_battle;
        private FinestraVittoria FinestraVittoria;


        public FaseTurno(int Fase, Log logForm, Mazzo mazzoUser, Mazzo mazzoCPU, Mano manoUser, Mano manoCPU, ManoForm manoForm,
            Mazzo cimiteroUser,Mazzo cimiteroCPU, Mazzo carteRimosseUser, Mazzo carteRimosseCPU,int giocatoreDiTurno,int numeroTurno, int LifePointsUser,
            int LifePointsCPU, Slot[] slotPersonaggiUser, Slot[] slotPersonaggiCPU, Slot[] slotMagieUser, Slot[] slotMagieCPU, Slot[] magiaTerrenoUser,
            Slot[] magiaTerrenoCPU, Battaglia my_battle)
        {
            this.Fase = Fase;
            this.logForm = logForm;
            this.mazzoCPU = mazzoCPU;
            this.manoCPU = manoCPU;
            this.manoUser = manoUser;
            this.mazzoUser = mazzoUser;
            this.manoForm = manoForm;
            this.carteRimosseCPU = carteRimosseCPU;
            this.carteRimosseUser = carteRimosseUser;
            this.cimiteroUser = cimiteroUser;
            this.cimiteroCPU = cimiteroCPU;
            this.giocatoreDiTurno = giocatoreDiTurno;
            this.LifePointsCPU = LifePointsCPU;
            this.LifePointsUser = LifePointsUser;
            this.slotMagieCPU = slotMagieCPU;
            this.slotMagieUser = slotMagieUser;
            this.slotPersonaggiCPU = slotPersonaggiCPU;
            this.slotPersonaggiUser = slotPersonaggiUser;
            this.magiaTerrenoCPU = magiaTerrenoCPU;
            this.magiaTerrenoUser = magiaTerrenoUser;
            this.my_battle = my_battle;



        }

        public void CambiaFase(int nuovaFase)
        {
            Fase = nuovaFase;
            string nomeFase = ((Turno.Fasi)Fase).ToString();
            logForm.AggiungiMessaggio($"\n{nomeFase}");

            switch (Fase)
            {
                case (int)Turno.Fasi.StartTurn:
                    if (numeroTurno == 0)
                    { numeroTurno++; }
                    logForm.AggiungiMessaggio($"\nTURNO {numeroTurno}");
                    evocazioni_normali_rimaste = 1;

                    // Se la partita è finita, esci
                    AvanzaFase();
                    break;
                    
                case (int)Turno.Fasi.DrawPhase:
                    PescaCarta();
                   // Se la partita è finita, esci
                    AvanzaFase();
                    break;

                case (int)Turno.Fasi.MainPhase1:
                    Choice_MainPhase1 = new Scelta(0, logForm, mazzoUser, mazzoCPU, manoUser, manoCPU, manoForm,
                cimiteroUser, cimiteroCPU, carteRimosseUser, carteRimosseCPU, giocatoreDiTurno, numeroTurno, LifePointsUser, LifePointsCPU,
                slotPersonaggiUser, slotPersonaggiCPU, slotMagieUser, slotMagieCPU, magiaTerrenoUser, magiaTerrenoCPU,my_battle);
                    Choice_MainPhase1.EseguiScelta(Fase,evocazioni_normali_rimaste);
                   // Se la partita è finita, esci
                    AvanzaFase();
                    break;

                case (int)Turno.Fasi.BattlePhase:
                    Choice_BattlePhase = new Scelta(0, logForm, mazzoUser, mazzoCPU, manoUser, manoCPU, manoForm,
                cimiteroUser, cimiteroCPU, carteRimosseUser, carteRimosseCPU, giocatoreDiTurno, numeroTurno, LifePointsUser, LifePointsCPU,
                slotPersonaggiUser, slotPersonaggiCPU, slotMagieUser, slotMagieCPU, magiaTerrenoUser, magiaTerrenoCPU, my_battle);
                    Choice_BattlePhase.EseguiScelta(Fase, evocazioni_normali_rimaste);
                   // Se la partita è finita, esci
                    AvanzaFase();
                    break;

                case (int)Turno.Fasi.MainPhase2:
                     // Se la partita è finita, esci
                    AvanzaFase();
                    break;

                case (int)Turno.Fasi.EndPhase:
                   
                    if (my_battle.ControllaFinePartita(LifePointsUser, LifePointsCPU)){ return; } // Se la partita è finita, esci
                    else{
                        CreaNuovoTurno();
                        AvanzaFase();
                        break;
                    }
                       
                    
            }
        }

        private void AvanzaFase()
        {
            if (Fase < (int)Turno.Fasi.EndPhase)
            {
                CambiaFase(Fase + 1);
            }
        }

        private void PescaCarta()
        {
            if (giocatoreDiTurno == 1) // User
            {
                if (mazzoUser.Carte.Count > 0)
                {
                    Carta cartaPescata = mazzoUser.Carte[0];
                    mazzoUser.Carte.RemoveAt(0);
                    manoUser.AggiungiCarta(cartaPescata);
                    manoForm.AggiornaMano(); // Mostra la carta nella GUI

                    logForm.AggiungiMessaggio($"Hai pescato: {cartaPescata.Nome}");
                }
                else
                {
                    
                        if (my_battle.fineMazzoPerdi)
                        {
                            logForm.AggiungiMessaggio($"{(giocatoreDiTurno == 1 ? "User" : "CPU")} ha tentato di pescare da un mazzo vuoto e ha perso!");
                            FinestraVittoria = new FinestraVittoria(giocatoreDiTurno == 1 ? "CPU" : "User"); // Perde chi ha provato a pescare
                            
                        }
                        else
                        {
                            logForm.AggiungiMessaggio($"{(giocatoreDiTurno == 1 ? "User" : "CPU")} ha un mazzo vuoto e non può pescare.");
                            
                        }
                    
                }
            }
            else // CPU
            {
                if (mazzoCPU.Carte.Count > 0)
                {
                    mazzoCPU.Carte.RemoveAt(0);
                    logForm.AggiungiMessaggio("La CPU ha pescato una carta.");
                }
                else
                {
                    if (mazzoCPU.Carte.Count == 0)
                    {
                        if (my_battle.fineMazzoPerdi)
                        {
                            logForm.AggiungiMessaggio($"{(giocatoreDiTurno == 1 ? "User" : "CPU")} ha tentato di pescare da un mazzo vuoto e ha perso!");
                            FinestraVittoria = new FinestraVittoria(giocatoreDiTurno == 1 ? "CPU" : "User"); // Perde chi ha provato a pescare
                           
                        }
                        else
                        {
                            logForm.AggiungiMessaggio($"{(giocatoreDiTurno == 1 ? "User" : "CPU")} ha un mazzo vuoto e non può pescare.");
                           
                        }
                    }
                }
            }
        }


     
        

        private void CreaNuovoTurno()
        {
            if (numeroTurno==0)
                { numeroTurno++; }
            
                logForm.AggiungiMessaggio($"\nFINE TURNO {numeroTurno}" +
                                $"---------------------------------------------- \r\n");
            // Cambia giocatore
            giocatoreDiTurno = (giocatoreDiTurno == 1) ? 2 : 1;
            numeroTurno++;

            // Controlla se il mazzo è vuoto
            bool mazzoDisponibile = (giocatoreDiTurno == 1 && mazzoUser.Carte.Count > 0) ||
                                    (giocatoreDiTurno == 2 && mazzoCPU.Carte.Count > 0);

           
                
                CambiaFase((int)Turno.Fasi.StartTurn);
           
        }


    }
}


