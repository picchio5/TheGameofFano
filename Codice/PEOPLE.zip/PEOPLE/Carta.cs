﻿using System;
using System.Drawing;

namespace PEOPLE
{
    public class Carta
    {
        public string Nome { get; private set; }    // Nome della carta (es. "Adele")
        public int Potenza { get; private set; }     // Valore numerico della carta
        public string ImmaginePath { get; private set; } // Percorso dell'immagine

        // Costruttore
        public Carta(string nome, int potenza, string immaginePath)
        {
            Nome = nome;
            Potenza= potenza;
            ImmaginePath = immaginePath;
        }

        // Metodo per ottenere l'immagine della carta
        public Image GetImmagine()
        {
            try
            {
                return Image.FromFile(ImmaginePath);
            }
            catch
            {
                return null; // Se l'immagine non esiste, restituisce null
            }
        }

        // Rappresentazione testuale della carta
        public override string ToString()
        {
            return $"{Nome} (Potenza: {Potenza})";
        }
    }
}
