﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace PEOPLE
{
    public class CimiteroForm : Form
    {
        public CimiteroForm(Mazzo cimitero)
        {
            this.Text = "Cimitero";
            this.Size = new Size(800, 200);
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.StartPosition = FormStartPosition.CenterScreen;

            FlowLayoutPanel panel = new FlowLayoutPanel
            {
                Dock = DockStyle.Fill,
                AutoScroll = true
            };

            foreach (Carta carta in cimitero.Carte)
            {
                PictureBox pictureBox = new PictureBox
                {
                    Size = new Size(100, 150),
                    Image = Image.FromFile(carta.ImmaginePath),
                    SizeMode = PictureBoxSizeMode.StretchImage,
                    BorderStyle = BorderStyle.FixedSingle
                };
                panel.Controls.Add(pictureBox);
            }

            this.Controls.Add(panel);
        }
    }
}
