﻿using System.Collections.Generic;

namespace PEOPLE
{
    public class Mano
    {
        public List<Carta> Carte { get; private set; }

        public Mano()
        {
            Carte = new List<Carta>();
        }

        public void AggiungiCarta(Carta carta)
        {
            Carte.Add(carta);
        }
    }
}

