﻿using System;
using System.Collections.Generic;
using System.IO;
using Newtonsoft.Json;

namespace PEOPLE
{
    public static class ArchivioCarte
    {
        public static List<Carta> TutteLeCarte { get; private set; } = new List<Carta>();

        public static void CaricaCarte()
        {
            string percorsoFile = "C:\\Users\\stefa\\Documents\\CARTE PEOPLE\\databaseCarte.json";

            if (File.Exists(percorsoFile))
            {
                string json = File.ReadAllText(percorsoFile);
                TutteLeCarte = JsonConvert.DeserializeObject<List<Carta>>(json);
            }

            if (TutteLeCarte == null || TutteLeCarte.Count == 0)
            {
                // Se il file non esiste o è vuoto, creiamo alcune carte di default
                TutteLeCarte = new List<Carta>
                {
                    new Carta("Adele", 100, "C:\\Users\\stefa\\Documents\\CARTE PEOPLE\\Adele_X.png"),
                    new Carta("Adam Smith", 130, "C:\\Users\\stefa\\Documents\\CARTE PEOPLE\\Adam_Smith_X.png")
                };

                // Scriviamo il file JSON
                SalvaCarte();
            }
        }

        public static void SalvaCarte()
        {
            string percorsoFile = "C:\\Users\\stefa\\Documents\\CARTE PEOPLE\\databaseCarte.json";
            File.WriteAllText(percorsoFile, JsonConvert.SerializeObject(TutteLeCarte, Formatting.Indented));
        }
    }
}
