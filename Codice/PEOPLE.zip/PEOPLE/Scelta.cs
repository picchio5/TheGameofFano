﻿using System;
using Microsoft.VisualBasic.Logging;
using System.Timers;
namespace PEOPLE
{
    public class Scelta
    {
        public int Fase { get; private set; }
        private Log logForm;
        private Mazzo mazzoUser;
        private Mazzo mazzoCPU;
        private Mano manoUser;
        private Mano manoCPU;
        private int giocatoreDiTurno,pause;
        private ManoForm manoForm;
        private int numeroTurno, LifePointsUser, LifePointsCPU;
        private Mazzo cimiteroUser;
        private Mazzo cimiteroCPU;
        private Mazzo carteRimosseUser;
        private Mazzo carteRimosseCPU;
        private Slot[] slotPersonaggiUser, slotPersonaggiCPU, slotMagieUser, slotMagieCPU;
        private Slot[] magiaTerrenoUser, magiaTerrenoCPU;
        private Random random = new Random();
        private Battaglia my_battle;


        public Scelta(int Fase, Log logForm, Mazzo mazzoUser, Mazzo mazzoCPU, Mano manoUser, Mano manoCPU, ManoForm manoForm,
            Mazzo cimiteroUser, Mazzo cimiteroCPU, Mazzo carteRimosseUser, Mazzo carteRimosseCPU, int giocatoreDiTurno, int numeroTurno, int LifePointsUser,
            int LifePointsCPU, Slot[] slotPersonaggiUser, Slot[] slotPersonaggiCPU, Slot[] slotMagieUser, Slot[] slotMagieCPU, Slot[] magiaTerrenoUser,
            Slot[] magiaTerrenoCPU, Battaglia my_battle)
        {
            this.Fase = Fase;
            this.logForm = logForm;
            this.mazzoCPU = mazzoCPU;
            this.manoCPU = manoCPU;
            this.manoUser = manoUser;
            this.mazzoUser = mazzoUser;
            this.manoForm = manoForm;
            this.carteRimosseCPU = carteRimosseCPU;
            this.carteRimosseUser = carteRimosseUser;
            this.cimiteroUser = cimiteroUser;
            this.cimiteroCPU = cimiteroCPU;
            this.giocatoreDiTurno = giocatoreDiTurno;
            this.LifePointsCPU = LifePointsCPU;
            this.LifePointsUser = LifePointsUser;
            this.slotMagieCPU = slotMagieCPU;
            this.slotMagieUser = slotMagieUser;
            this.slotPersonaggiCPU = slotPersonaggiCPU;
            this.slotPersonaggiUser = slotPersonaggiUser;
            this.magiaTerrenoCPU = magiaTerrenoCPU;
            this.magiaTerrenoUser = magiaTerrenoUser;
            this.my_battle = my_battle;


        }

        public void EseguiScelta(int nuovaFase, int evocazioni_normali_rimaste)
        {


            switch (nuovaFase)
            {
                case (int)Turno.Fasi.MainPhase1:
                    GiocaAzioniLente(giocatoreDiTurno, evocazioni_normali_rimaste);
                    break;
                case (int)Turno.Fasi.BattlePhase:

                    Attacca();
                    break;
                case (int)Turno.Fasi.MainPhase2:
                    SecondaStrategia();
                    break;
                case (int)Turno.Fasi.EndPhase:
                    FineTurno();
                    break;

            }
        }


        private void GiocaAzioniLente(int giocatoreDiTurno, int evoc_normali_rimaste)
        {


            if (evoc_normali_rimaste > 0)
            {
                int evoca_pers_o_no = random.Next(1, 3) - 1;
                if (evoca_pers_o_no == 1)
                {
                    if (giocatoreDiTurno == 1)
                    {
                        EvocazioneNormalePersonaggio(manoUser, slotPersonaggiUser, slotMagieUser, magiaTerrenoUser, evoc_normali_rimaste);
                    }
                    else
                    {
                        EvocazioneNormalePersonaggio(manoCPU, slotPersonaggiCPU, slotMagieCPU, magiaTerrenoCPU, evoc_normali_rimaste);
                    }


                    evoc_normali_rimaste = 0;
                }

            }
        }


        private void EvocazioneNormalePersonaggio(Mano mano, Slot[] SlotPers, Slot[] SltoMag, Slot[] SlotMagTerr, int evocazioni_norlai_rimase)
        {
            for (int j = mano.Carte.Count - 1; j >= 0; j--)
            {
                if (evocazioni_norlai_rimase > 0)
                {
                    Carta carta = mano.Carte[j];
                    // Se è una carta personaggio e c'è uno slot libero
                    int ProvaSlot = random.Next(0, SlotPers.Length);
                    while (SlotPers[ProvaSlot].Occupato)
                    {
                        ProvaSlot = random.Next(0, SlotPers.Length);
                    }

                    SlotPers[ProvaSlot].AssegnaCarta(carta);
                    mano.Carte.Remove(carta);
                    evocazioni_norlai_rimase = 0;

                    logForm.AggiungiMessaggio($"{this.giocatoreDiTurno} evoca {carta.Nome} nello slot {ProvaSlot + 1}");
                    




                }
            }
        }


        private void Attacca()
        {
            Slot[] slotAttaccanti, slotDifensori;
            int danniTotali = 0;

            if (giocatoreDiTurno == 1)
            {
                slotAttaccanti = slotPersonaggiUser;
                slotDifensori = slotPersonaggiCPU;
            }
            else
            {
                slotAttaccanti = slotPersonaggiCPU;
                slotDifensori = slotPersonaggiUser;
            }

            // Ogni personaggio ha il 50% di possibilità di attaccare
            foreach (var slot in slotAttaccanti)
            {
                if (slot.Occupato)
                {
                    int attaccoSiONo = random.Next(0, 2);
                    if (attaccoSiONo == 1)
                    {
                        logForm.AggiungiMessaggio($"{slot.CartaOccupante.Nome} decide di attaccare!");
                    }
                }
            }

            // Ora chiamiamo `Blocca()` per gestire i blocchi e lo scontro
            Blocca(slotAttaccanti, slotDifensori);

            // Il danno ai Life Points è già calcolato in `Blocca()`
        }

       

        private void Blocca(Slot[] slotAttaccanti, Slot[] slotDifensori)
        {
            Dictionary<Slot, List<Slot>> attaccantiVsDifensori = new Dictionary<Slot, List<Slot>>();

            foreach (var slotDifensore in slotDifensori)
            {
                if (slotDifensore.Occupato)
                {
                    int decideDiBloccare = random.Next(0, 2); // 50% di probabilità di bloccare
                    if (decideDiBloccare == 1)
                    {
                        // Scegli un attaccante casuale da bloccare
                        List<Slot> attaccantiDisponibili = slotAttaccanti.Where(a => a.Occupato).ToList();
                        if (attaccantiDisponibili.Count > 0)
                        {
                            Slot attaccanteScelto = attaccantiDisponibili[random.Next(0, attaccantiDisponibili.Count)];

                            if (!attaccantiVsDifensori.ContainsKey(attaccanteScelto))
                            {
                                attaccantiVsDifensori[attaccanteScelto] = new List<Slot>();
                            }
                            attaccantiVsDifensori[attaccanteScelto].Add(slotDifensore);
                        }
                    }
                }
            }

            // Risoluzione degli scontri
            foreach (var attaccante in attaccantiVsDifensori.Keys)
            {
                List<Slot> difensori = attaccantiVsDifensori[attaccante];
                int dannoAttaccante = attaccante.CartaOccupante.Potenza;
                int dannoTotaleDifensori = difensori.Sum(d => d.CartaOccupante.Potenza);

                // Scegli un difensore casuale a cui infliggere i danni dell'attaccante
                Slot difensoreColpito = difensori[random.Next(0, difensori.Count)];

                logForm.AggiungiMessaggio($"{attaccante.CartaOccupante.Nome} viene bloccato da {difensori.Count} difensori!");

             



                // Assegna i danni
                if (dannoAttaccante >= difensoreColpito.CartaOccupante.Potenza)
                {
                    logForm.AggiungiMessaggio($"{difensoreColpito.CartaOccupante.Nome} muore!");

                    
                   


                    cimiteroUser.AggiungiCarta(difensoreColpito.CartaOccupante);
                    difensoreColpito.RimuoviCarta();
                    my_battle.AggiornaCimiteroUI(); // ✅ Aggiorna la PictureBox del cimitero
                }

                if (dannoTotaleDifensori >= attaccante.CartaOccupante.Potenza)
                {
                    logForm.AggiungiMessaggio($"{attaccante.CartaOccupante.Nome} muore!");
                  


                    cimiteroCPU.AggiungiCarta(attaccante.CartaOccupante);
                    attaccante.RimuoviCarta();
                    my_battle.AggiornaCimiteroUI(); // ✅ Aggiorna la PictureBox del cimitero
                }
            }

            // Gli attaccanti non bloccati infliggono danni ai Life Points
            int danniTotali = 0;
            foreach (var slot in slotAttaccanti)
            {
                if (slot.Occupato && !attaccantiVsDifensori.ContainsKey(slot))
                {
                    danniTotali += slot.CartaOccupante.Potenza;
                    logForm.AggiungiMessaggio($"{slot.CartaOccupante.Nome} attacca direttamente e infligge {slot.CartaOccupante.Potenza} danni!");
                    

                }
            }

            // Applica i danni ai Life Points
            if (giocatoreDiTurno == 1)
            {
                LifePointsCPU -= danniTotali;
                if (LifePointsCPU < 0)
                {
                    logForm.AggiungiMessaggio("CPU ha perso! User vince!");
                    //my_battle.ControllaFinePartita(LifePointsUser, LifePointsCPU);
                }
                my_battle.AggiornaLifePointsUI(2, LifePointsCPU);
            }
            else
            {
                LifePointsUser -= danniTotali;
                if (LifePointsUser < 0) {
                    logForm.AggiungiMessaggio("User ha perso! CPU vince!");
                   // my_battle.ControllaFinePartita(LifePointsUser, LifePointsCPU);
                }
                my_battle.AggiornaLifePointsUI(1, LifePointsUser);
            }
        }




        


        private void SecondaStrategia()
        {
           
        }

        private void FineTurno()
        {
            logForm.AggiungiMessaggio("CPU termina il turno.");
           
        }

        
        
           

    }
}
