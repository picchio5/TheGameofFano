namespace PEOPLE
{
    public partial class SchermataTitolo : Form
    {
        public SchermataTitolo()
        {
            InitializeComponent();
        }

        private void Avvia_Battaglia_Con_CPU_Click(object sender, EventArgs e)
        {
            int DeckSize = 9;
            int MaxLifePoints = 1000;
            float IsMyDeckRandom = 1.0f;
            float IsCPUDeckRandom = 1.0f;
            int CarteInMano = 3;
            bool fineMazzoPerdi = false;            // Apri il form "Log"
            Log logForm = new Log(DeckSize, IsMyDeckRandom, IsCPUDeckRandom, MaxLifePoints, CarteInMano);
            bool ShowForms = true;

            if (ShowForms)
            {
                logForm.Show();
            }

            Battaglia finestraBattaglia = new Battaglia(DeckSize, IsMyDeckRandom, IsCPUDeckRandom, MaxLifePoints, CarteInMano, logForm, fineMazzoPerdi, ShowForms);


            if (ShowForms)
            {
                finestraBattaglia.Show();
            }
            this.Hide(); // Nasconde la schermata del titolo
        }

        private void Avvia_X_Battaglie_CPU_vs_CPU_Click(object sender, EventArgs e)
        {
            if (int.TryParse(Numero_Battaglie_CPU_vs_CPU.Text, out int numeroBattaglie))
            {
                int numeroVittorieUser = 0;
                int numeroVittorieCPU = 0;

                int DeckSize = 9;
                int MaxLifePoints = 1000;
                float IsMyDeckRandom = 1.0f;
                float IsCPUDeckRandom = 1.0f;
                int CarteInMano = 3;
                bool fineMazzoPerdi = false;
                bool ShowForms = false;

                for (int i = 0; i < numeroBattaglie; i++)
                {
                    Log logForm = new Log(DeckSize, IsMyDeckRandom, IsCPUDeckRandom, MaxLifePoints, CarteInMano);
                    Battaglia finestraBattaglia = new Battaglia(DeckSize, IsMyDeckRandom, IsCPUDeckRandom, MaxLifePoints, CarteInMano, logForm, fineMazzoPerdi, ShowForms);

                    int vincitore = finestraBattaglia.Vincitore; // Assume che `Battaglia` abbia una propriet� `Vincitore`
                    if (vincitore == 1) numeroVittorieUser++;
                    if (vincitore == 2) numeroVittorieCPU++;

                    // Chiudi tutti i form tranne la SchermataTitolo
                    var formsDaChiudere = Application.OpenForms.Cast<Form>().Where(f => !(f is SchermataTitolo)).ToList();
                    foreach (var form in formsDaChiudere)
                    {
                        form.Close();
                    }

                }

                MessageBox.Show($"User ha vinto {numeroVittorieUser} volte.\nCPU ha vinto {numeroVittorieCPU} volte.",
                    "Risultati Battaglie", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("Inserisci un numero intero!", "Errore", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

    }
}
